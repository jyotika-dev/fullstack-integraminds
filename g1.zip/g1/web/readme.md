1. https://vitejs.dev/
2. npm create vite@latest web1 -- --template react
3. npm install
4. npm run dev
- npm install react-router-dom axios --save



