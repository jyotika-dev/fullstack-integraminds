import React from "react";


const DashboardPage = (props) => {
    return (
        <div>
            <h1>Dashboard</h1>
            <a href="/users">Users</a>
        </div>
    )
}