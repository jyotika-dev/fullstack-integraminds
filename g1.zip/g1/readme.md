1. Create a root folder in root directory. (projects)
2. Create a new folder in that project. (g1)


